import { initializeApp } from "firebase/app";
import {getFirestore} from "firebase/firestore";

const firebaseConfig = {
  apiKey: "AIzaSyAhI997KMWW53YJU55nlrbVmWUZn7t3-co",
  authDomain: "supermercado-marolio.firebaseapp.com",
  projectId: "supermercado-marolio",
  storageBucket: "supermercado-marolio.appspot.com",
  messagingSenderId: "259909973686",
  appId: "1:259909973686:web:416b419155f84188b59817"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);

export const db = getFirestore(app);